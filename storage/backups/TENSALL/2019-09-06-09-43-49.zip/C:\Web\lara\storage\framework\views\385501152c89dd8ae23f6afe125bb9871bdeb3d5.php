<?php $__env->startSection('title','Import and Export !'); ?>
<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
     <div class="container">
         <div class="card-text-center">
             <div class="card-header">
                <h8>使用者帳號匯出</h8>
             </div>
             <div class="card-body">
                 <ul class="nav nav-tabs card-header-tabs">
                     <li class="nav-item">
                         <a href="<?php echo e(route('userexport')); ?>" class="nav-link">Download Users file</a>
                     </li>

                 </ul>
             </div>
         </div>
         <div class="card">
             <div class="card-header">
                <h8>使用者帳號匯入</h8>
             </div>
             <div class="card-body">
                <form style="border: 1pt solid #a1cbef;margin: 10px;padding: 10px;" action="<?php echo e(route('userimport')); ?>" class="form" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if( Session::has('success')): ?>
                        <div class="alert alert-success">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
                            <p><?php echo e(Session::get('success')); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if( Session::has('fail')): ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
                            <p><?php echo e(Session::get('fail')); ?></p>
                        </div>
                    <?php endif; ?>

                    <input type="file" name="import_file" />
                    <button class="btn btn-primary">Import CSV</button>
                </form>
             </div>
         </div>
     </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/ImportAndExport.blade.php ENDPATH**/ ?>