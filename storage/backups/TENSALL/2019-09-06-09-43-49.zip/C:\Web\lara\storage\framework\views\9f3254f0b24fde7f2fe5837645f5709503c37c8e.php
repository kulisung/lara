<?php $__env->startSection('title','查詢系統'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <h5>查詢結果</h5>
        <p><a href=<?php echo e(route('searchs.search4'), false); ?> class="btn btn-success btn-sm">返回</a></p>
        </div>
        <div class="col-12 table-cont" id="table-cont">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>客戶代碼</th>
                        <th>客戶全名</th>
                        <th>銷貨日期</th>
                        <th>部門</th>
                        <th>品牌</th>
                        <th>四大類</th>
                        <th>內外銷</th>
                        <th>國家別</th>
                        <th>品名</th>
                        <th>數量</th>
                        <th>匯率\單位</th>
                        <th>未稅金額</th>
                        <th>稅額</th>
                        <th>單別</th>
                        <th>單號</th>
                        <th>序號</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sa_arrays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sa_array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($sa_array->TG004, false); ?></td>
                        <td><?php echo e($sa_array->TG007, false); ?></td>
                        <td><?php echo e($sa_array->TG003, false); ?></td>
                        <td><?php echo e($sa_array->TG005, false); ?></td>
                        <td><?php echo e($sa_array->MB008, false); ?></td>
                        <td><?php echo e($sa_array->MB006, false); ?></td>
                        <td><?php echo e($sa_array->MA038, false); ?></td>
                        <td><?php echo e($sa_array->MA019, false); ?></td>
                        <td><?php echo e($sa_array->TH005, false); ?></td>
                        <td><?php echo e($sa_array->QTY, false); ?></td>
                        <td><?php echo e($sa_array->TG012, false); ?></td>
                        <td><?php echo e($sa_array->TH037, false); ?></td>
                        <td><?php echo e($sa_array->TH038, false); ?></td>
                        <td><?php echo e($sa_array->TH001, false); ?></td>
                        <td><?php echo e($sa_array->TH002, false); ?></td>
                        <td><?php echo e($sa_array->TH003, false); ?></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/searchs/SA_Begin_Check.blade.php ENDPATH**/ ?>