<?php $__env->startSection('title','資料查詢系統'); ?>
<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<?php if(auth()->user()->user_level==9 or auth()->user()->user_level==5): ?>
<div class="container" style="background-color:#DEFFFF;">
    <div class="row">
        <div class="col-12">
            <h5>#結帳前檢查(測試)</h5>
            <form method="post" action=<?php echo e(route('finance.fin_b4chk'), false); ?>>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                    <label>結算的起始年月(格式為ex:201901)</label>
                    <input type="text" name="fin_date1">
                    <button type="submit" class="btn btn-primary btn-sm">結帳前檢查</button>
                    <button type="submit" class="btn btn-secondary btn-sm" formaction=<?php echo e(route('finance.fin_b4_chk'), false); ?>>B4_CHK</button>
                    <button type="submit" class="btn btn-secondary btn-sm" formaction=<?php echo e(route('finance.fin_b4chk'), false); ?> onclick="return confirm('確認是否匯出Excel?');">匯出Excel</button>
            </div>        
            </form>
            <h5>#結帳後檢查(測試)</h5>
            <form method="post" action=<?php echo e(route('finance.fin_b4chk'), false); ?>>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                    <label>結算的起始年月(格式為ex:201901)</label>
                    <input type="text" name="fin_date3">
                    <button type="submit" class="btn btn-primary btn-sm">結帳後檢查</button>
                    <button type="submit" class="btn btn-secondary btn-sm" formaction=<?php echo e(route('finance.fin_b4chk'), false); ?> onclick="return confirm('確認是否匯出Excel?');">匯出Excel</button>
            </div>        
            </form>
        </div>
    </div>
</div> 
<?php endif; ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/finance/fsearch2.blade.php ENDPATH**/ ?>