<?php $__env->startSection('title','測試系統'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h2>測試列表</h2>
        <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary btn-sm">返回</a>
        </div>
        <div class="col-12">
            <form method="post" action="<?php echo e(route('posts.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title">標題</label>
                    <input type="text" class="form-control" name="title" id="title" value="">
                </div>
                <div class="form-group">
                    <label for="content">內容</label>
                    <textarea name="content" id="content" class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label for="files">附件</label>
                    <input type="file" class="form-group" name="files[]" id="files" multiple>
                </div>
                <button type="submit" class="btn btn-primary btn-sm">儲存</button>
            </form>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/posts/create.blade.php ENDPATH**/ ?>