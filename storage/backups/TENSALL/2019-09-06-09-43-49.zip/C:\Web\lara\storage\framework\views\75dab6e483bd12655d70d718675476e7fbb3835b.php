<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <a class="navbar-brand mb-0 h1" href=<?php echo e(route('index')); ?>>Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                  <a class="nav-link font-weight-bold" href=<?php echo e(route('index')); ?>>Home <span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item">
                  <a class="nav-link font-weight-bold" href=<?php echo e(route('posts.index')); ?>>測試系統</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('searchs.index')); ?>>資料查詢</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('upload')); ?>>資料匯入</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('export')); ?>>資料匯出</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('result')); ?>>DB連線檢查</a>                    
                </li>


                <li class="nav-item">
                  <a class="nav-link font-weight-bold" href="#">Other</a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">

                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('login')); ?>>Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('register')); ?>>Register</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();"> Logout
                    </a>
                </li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                    </form>

            </ul>
        </div>
</nav><?php /**PATH C:\Web\lara\resources\views/layouts/navbar1.blade.php ENDPATH**/ ?>