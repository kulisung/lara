<?php $__env->startSection('title','UserEdit'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12"><br>
            <form method="post" action="<?php echo e(route('posts.UsersUpdate', $users->username), false); ?>">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PATCH'), false); ?>

                <div class="card">
                    <div class="card-header">
                    使用者資訊
                </div>
                <div class="card-body">
                    <div class="shadow p-1 bg-white rounded">Login-ID：<?php echo e($users->username, false); ?></div>
                    <div class="shadow p-1 bg-white rounded">Name：
                    <input type="text" name="name" value="<?php echo e($users->name, false); ?>"></div>
                    <div class="shadow p-1 bg-white rounded">User Level：
                    <input type="text" name="user_level" value="<?php echo e($users->user_level, false); ?>"></div>
                    <div class="shadow p-1 bg-white rounded">E-mail：
                    <input type="text" name="email" value="<?php echo e($users->email, false); ?>"></div>
                </div>
                </div>
                <a href="<?php echo e(route('posts.UsersIndex'), false); ?>" class="btn btn-secondary btn-sm">返回</a>
                <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('是否確認儲存?');">儲存</button>
            </form>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/posts/UserEdit.blade.php ENDPATH**/ ?>