<?php $__env->startSection('title','查詢系統'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <h2>查詢結果</h2>
        <a href=<?php echo e(route('searchs.index')); ?> class="btn btn-success btn-sm">返回</a>
        </div>
        <br>
        <div class="col-12" style="width:500px;height:500px;overflow:auto;">
            <br>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th><span style="font-size:14px;">客戶代碼</th>
                        <th><span style="font-size:14px;">客戶全名</th>
                        <th><span style="font-size:14px;">銷貨日期</th>
                        <th><span style="font-size:14px;">部門</th>
                        <th><span style="font-size:14px;">品牌</th>
                        <th><span style="font-size:14px;">四大類</th>
                        <th><span style="font-size:14px;">品號</th>
                        <th><span style="font-size:14px;">品名</th>
                        <th><span style="font-size:14px;">數量</th>
                        <th><span style="font-size:14px;">匯率\單位</th>
                        <th><span style="font-size:14px;">發票起號</th>
                        <th><span style="font-size:14px;">發票迄號</th>
                        <th><span style="font-size:14px;">單別</th>
                        <th><span style="font-size:14px;">單號</th>
                        <th><span style="font-size:14px;">序號</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><span style="font-size:16px;"><?php echo e($inv->TG004); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TG007); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TG003); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TG005); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->MB008); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->MB006); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TH004); ?></td>
                        <td><span style="font-size:16px;"><?php echo e($inv->TH005); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->QTY); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TG012); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TG098); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TG014); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TH001); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TH002); ?></td>
                        <td><span style="font-size:14px;"><?php echo e($inv->TH003); ?></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/searchs/show.blade.php ENDPATH**/ ?>