<?php $__env->startSection('title','資料查詢'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h2>資料查詢</h2>
            <a class="btn btn-primary" href="#" role="button">賢齊進退貨查詢</a>
            <a class="btn btn-primary" href="#" role="button">Excel匯出測試</a>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/auth/search.blade.php ENDPATH**/ ?>