<?php $__env->startSection('title','簡易公告系統'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <h3>公告內容列表</h3>
        <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('posts.create'), false); ?>" class="btn btn-success btn-sm">新增內容</a>
        <?php endif; ?>
        </div>
        <br>
        <div class="col-12">
            <br>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>發表時間</th>
                        <th>標題</th>
                        <th>發表人</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($post->created_at, false); ?></td>
                        <td><a href="<?php echo e(route('posts.show',$post->id), false); ?>"><?php echo e($post->title, false); ?></a></td>
                        <td><?php echo e($post->user_id, false); ?></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/posts/index.blade.php ENDPATH**/ ?>