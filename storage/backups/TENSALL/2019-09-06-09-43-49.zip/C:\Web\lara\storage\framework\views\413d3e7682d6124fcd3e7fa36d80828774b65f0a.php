<?php $__env->startSection('title','測試系統'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
        <br>
        </div>
        <div>
        <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-secondary btn-sm">返回</a>
        <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('posts.edit',$post->id)); ?>" class="btn btn-primary btn-sm">編輯</a>
        <a href="#" class="btn btn-danger btn-sm" onclick="document.getElementById('delete').submit()">刪除</a>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('posts.destroy',$post->id)); ?>" id='delete'>
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('DELETE')); ?>

        </form>
        </div>
        <div class="col-12"><br>
            <div class="card">
                <div class="card-header">
                    <h3><?php echo e($post->title); ?></h3>
                </div>
                <div class="card-body">
                    <?php echo e($post->content); ?>

                </div>
            </div>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/posts/show.blade.php ENDPATH**/ ?>