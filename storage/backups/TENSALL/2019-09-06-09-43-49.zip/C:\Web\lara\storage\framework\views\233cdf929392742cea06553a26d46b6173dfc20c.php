<?php $__env->startSection('title','UsersList'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <h5>使用者列表</h5>
        </div>
        <br>
        <div class="col-12">
            <br>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Login-ID</th>
                        <th>Name</th>
                        <th>User-Level</th>
                        <th>E-mail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('posts.UsersEdit',$user->username), false); ?>"><?php echo e($user->username, false); ?></a></td>
                        <td><?php echo e($user->name, false); ?></td>
                        <td><?php echo e($user->user_level, false); ?></td>
                        <td><?php echo e($user->email, false); ?></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/posts/UsersIndex.blade.php ENDPATH**/ ?>