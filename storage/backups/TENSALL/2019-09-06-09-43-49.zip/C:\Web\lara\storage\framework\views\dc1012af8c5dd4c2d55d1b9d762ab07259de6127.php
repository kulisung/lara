<?php $__env->startSection('title','UserEdit'); ?>
<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<?php if(auth()->user()->user_level==9): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 "><br>
            <form method="post" action="<?php echo e(route('UsersProfile.UsersResetPassword', $user->username), false); ?>">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PATCH'), false); ?>

                <div class="card">
                    <div class="card-header">
                    使用者資訊
                </div>
                <div class="card-body">
                        <div class="form-group row">
                            <label for="loginid" class="col-md-4 col-form-label text-md-right">Login-ID</label>
                            <div class="col-md-6">
                            <label for="loginid" class="col-md-4 col-form-label text-md-right"><?php echo e($user->username, false); ?></label>
                            </div>

                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password'), false); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message, false); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>
                </div>
                <div><br>
                <a href="<?php echo e(route('UsersProfile.UsersIndex'), false); ?>" class="btn btn-secondary btn-sm">返回</a>
                <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('是否確認儲存?');">儲存</button>
                </div>
            </form>
        </div>
    </div>
</div>  
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/UsersProfile/UsersResetPWD.blade.php ENDPATH**/ ?>