<?php $__env->startSection('title','查詢系統'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <h5>賢齊進退貨資料查詢結果</h5>
        <p><a href=<?php echo e(route('searchs.search1'), false); ?> class="btn btn-success btn-sm">返回</a></p>
        </div>
        <div class="col-12 table-cont" id="table-cont">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>進貨單別</th>
                        <th>進貨單號</th>
                        <th>進貨序號</th>
                        <th>進貨品號</th>
                        <th>進貨數量</th>
                        <th>合計已退貨數量</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $purths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($purth->TH001, false); ?></td>
                        <td><?php echo e($purth->TH002, false); ?></td>
                        <td><?php echo e($purth->TH003, false); ?></td>
                        <td><?php echo e($purth->TH004, false); ?></td>
                        <td><?php echo e($purth->TH007, false); ?></td>
                        <td><?php echo e($purth->SUMQTY, false); ?></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/searchs/purth_result.blade.php ENDPATH**/ ?>