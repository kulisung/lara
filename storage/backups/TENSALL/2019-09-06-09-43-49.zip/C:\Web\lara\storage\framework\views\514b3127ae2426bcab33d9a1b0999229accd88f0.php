<?php $__env->startSection('title','SQLSRV_Check'); ?>
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\DB;

if( DB::connection('sqlsrv') ) {
     echo "Connection established.連線成功!!<br />";
     echo $conninfo;
}else{
     echo "Connection could not be established.連結失敗!?<br />";
}
// Close the connection.
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/auth/sqlsrv.blade.php ENDPATH**/ ?>