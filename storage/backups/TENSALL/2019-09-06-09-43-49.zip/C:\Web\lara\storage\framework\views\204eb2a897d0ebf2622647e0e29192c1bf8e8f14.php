<?php $__env->startSection('title','查詢系統'); ?>
<?php $__env->startSection('head'); ?>
<style>
#tabs-nav{
   margin: 0;
   padding: 0;
   position: relative;
   text-align: left
}
a.tabs-menu {
   display: inline-block;
   background-color: #1b91ab;
   font-size: 14px;
   font-family: Arial,Helvetica,sans-serif;
   color: #fff;
   padding: 5px 10px;
   text-shadow: 1px 1px 0px #1b91ab;
   font-weight: bold;
   text-decoration: none;
   border: solid 1px #1b91ab;
   border-bottom: 0;
   border-radius: 3px 3px 0 0;
}
a.tabs-menu.tabs-menu-active {
   background-color: #fff;
   text-shadow: 1px 1px 0px #ffffff;
   border: solid 1px #1b91ab;
   color: #6b6b6b;
   border-bottom: 0;
}
.tabs-container {
   border: solid 1px #1b91ab;
   margin-top: -1px;
   max-height: 520px;
   background-color: #fff;
   overflow-x: scroll;
   overflow-y: scroll;
   overflow: hidden;
}
.tabs-panel {
   display: none;
   max-height: 520px;
   min-height: 100px;
   overflow: auto;
   padding: 10px;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
        <h5>查詢結果，請稍後...(資料量大)</h5>
        <p><a href=<?php echo e(route('finance.fsearch2'), false); ?> class="btn btn-success btn-sm">返回</a> 
        <label style='font-size:14px'>結算年月：<?php echo e($fin_chk, false); ?>，累計為該年度1月起計算。淨額資料筆數：<?php echo e($data_records, false); ?>筆。</label>
            <label style='font-size:14px'>銷貨資料筆數：<?php echo e($ship_records, false); ?>筆。</label>            
        </p>
        </div>
    <div id="js-tabs" style="width:100%">

        <div id="tabs-nav">
        <a href="#tab0" onclick="jsTabs(event,'tab0');return false" class="tabs-menu tabs-menu-active">淨額</a>
        <a href="#tab1" onclick="jsTabs(event,'tab1');return false" class="tabs-menu">銷貨</a>
        <a href="#tab2" onclick="jsTabs(event,'tab2');return false" class="tabs-menu">四大類\品牌單月未稅合計</a>
        <a href="#tab2" onclick="jsTabs(event,'tab3');return false" class="tabs-menu">四大類\品牌累計未稅合計</a>
        <a href="#tab2" onclick="jsTabs(event,'tab4');return false" class="tabs-menu">銷退\折讓\尾折未稅合計</a>
        <a href="#tab2" onclick="jsTabs(event,'tab5');return false" class="tabs-menu">銷退合計</a>
        </div>

        <div class="tabs-container">
            <div id="tab0" class="tabs-panel" style="display:block">
                <div class="col-12 table-cont">
                    <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>客戶代碼</th>
                            <th>客戶全名</th>
                            <th>銷貨日期</th>
                            <th>部門</th>
                            <th>品牌</th>
                            <th>四大類</th>
                            <th>內外銷</th>
                            <th>國家別</th>
                            <th>品名</th>
                            <th>數量</th>
                            <th>匯率\單位</th>
                            <th>未稅金額</th>
                            <th>稅額</th>
                            <th>單別</th>
                            <th>單號</th>
                            <th>序號</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $b4_chks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_chk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($b4_chk->TG004, false); ?></td>
                            <td><?php echo e($b4_chk->TG007, false); ?></td>
                            <td><?php echo e($b4_chk->TG003, false); ?></td>
                            <td><?php echo e($b4_chk->TG005, false); ?></td>
                            <td><?php echo e($b4_chk->MB008, false); ?></td>
                            <td><?php echo e($b4_chk->MB006, false); ?></td>
                            <td><?php echo e($b4_chk->MA038, false); ?></td>
                            <td><?php echo e($b4_chk->MA019, false); ?></td>
                            <td><?php echo e($b4_chk->TH005, false); ?></td>
                            <td><?php echo e($b4_chk->QTY, false); ?></td>
                            <td><?php echo e($b4_chk->TG012, false); ?></td>
                            <td><?php echo e($b4_chk->TH037, false); ?></td>
                            <td><?php echo e($b4_chk->TH038, false); ?></td>
                            <td><?php echo e($b4_chk->TH001, false); ?></td>
                            <td><?php echo e($b4_chk->TH002, false); ?></td>
                            <td><?php echo e($b4_chk->TH003, false); ?></td>
                        </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
            </div>

            <div id="tab1" class="tabs-panel" style="display:block">
                <div class="col-12 table-cont">
                    <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>客戶代碼</th>
                            <th>客戶全名</th>
                            <th>銷貨日期</th>
                            <th>部門</th>
                            <th>品牌</th>
                            <th>四大類</th>
                            <th>內外銷</th>
                            <th>國家別</th>
                            <th>品名</th>
                            <th>數量</th>
                            <th>匯率\單位</th>
                            <th>未稅金額</th>
                            <th>稅額</th>
                            <th>單別</th>
                            <th>單號</th>
                            <th>序號</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $b4_shipchks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_shipchk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($b4_shipchk->TG004, false); ?></td>
                            <td><?php echo e($b4_shipchk->TG007, false); ?></td>
                            <td><?php echo e($b4_shipchk->TG003, false); ?></td>
                            <td><?php echo e($b4_shipchk->TG005, false); ?></td>
                            <td><?php echo e($b4_shipchk->MB008, false); ?></td>
                            <td><?php echo e($b4_shipchk->MB006, false); ?></td>
                            <td><?php echo e($b4_shipchk->MA038, false); ?></td>
                            <td><?php echo e($b4_shipchk->MA019, false); ?></td>
                            <td><?php echo e($b4_shipchk->TH005, false); ?></td>
                            <td><?php echo e($b4_shipchk->QTY, false); ?></td>
                            <td><?php echo e($b4_shipchk->TG012, false); ?></td>
                            <td><?php echo e($b4_shipchk->TH037, false); ?></td>
                            <td><?php echo e($b4_shipchk->TH038, false); ?></td>
                            <td><?php echo e($b4_shipchk->TH001, false); ?></td>
                            <td><?php echo e($b4_shipchk->TH002, false); ?></td>
                            <td><?php echo e($b4_shipchk->TH003, false); ?></td>
                        </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
            </div>            

            <div id="tab2" class="tabs-panel" style="display:block">
                <div class="col-6 table-cont" style="float:left">
                    <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>四大類</th>
                            <th>四大類單月未稅合計</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $b4_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($b4_item->MB006, false); ?></td>
                            <td><?php echo e($b4_item->COST, false); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>

                <div class="col-6 table-cont" style="float:left">
                    <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>四大類</th>
                            <th>四大類累計未稅合計</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $b4_sumitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_sumitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($b4_sumitem->MB006, false); ?></td>
                            <td><?php echo e($b4_sumitem->COST, false); ?></td>
                        </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>

            </div>

            <div id="tab3" class="tabs-panel" style="display:block">
                <div class="col-6 table-cont" style="float:left">
                    <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>品牌</th>
                            <th>品牌單月未稅合計</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $b4_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($b4_brand->MB008, false); ?></td>
                            <td><?php echo e($b4_brand->COST, false); ?></td>
                        </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>

                <div class="col-6 table-cont" style="float:left">
                    <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>品牌</th>
                            <th>品牌累計未稅合計</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $b4_sumbrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_sumbrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($b4_sumbrand->MB008, false); ?></td>
                            <td><?php echo e($b4_sumbrand->COST, false); ?></td>
                        </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>

            </div>

            <div id="tab4" class="tabs-panel" style="display:block">
                <div class="col-12 table-cont">
                <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>單月銷退未稅合計</th>
                        <th>單月折讓未稅合計</th>
                        <th>單月尾折未稅合計</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <?php $__currentLoopData = $b4_returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($b4_return->COST, false); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $b4_allowances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_allowance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($b4_allowance->ML008, false); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $b4_discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($b4_discount->TD015, false); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>  

                </tbody>
                <thead>
                    <tr>
                        <th>累計銷退未稅合計</th>
                        <th>累計折讓未稅合計</th>
                        <th>累計尾折未稅合計</th>
                    </tr>
                </thead>
                <tbody>

                    <tr>
                        <?php $__currentLoopData = $b4_sumreturns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_sumreturn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($b4_sumreturn->COST, false); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $b4_sumallowances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_sumallowance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($b4_sumallowance->ML008, false); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $b4_sumdiscounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_sumdiscount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($b4_sumdiscount->TD015, false); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>  

                </tbody>
                </table>
                </div>
            </div>

            <div id="tab5" class="tabs-panel" style="display:block">
                <div class="col-12 table-cont">
                    <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>客戶代碼</th>
                            <th>客戶全名</th>
                            <th>銷貨日期</th>
                            <th>部門</th>
                            <th>品牌</th>
                            <th>四大類</th>
                            <th>內外銷</th>
                            <th>國家別</th>
                            <th>品名</th>
                            <th>數量</th>
                            <th>匯率\單位</th>
                            <th>未稅金額</th>
                            <th>稅額</th>
                            <th>單別</th>
                            <th>單號</th>
                            <th>序號</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $b4_shipbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b4_shipback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($b4_shipback->TI004, false); ?></td>
                            <td><?php echo e($b4_shipback->TI021, false); ?></td>
                            <td><?php echo e($b4_shipback->TI003, false); ?></td>
                            <td><?php echo e($b4_shipback->TG005, false); ?></td>
                            <td><?php echo e($b4_shipback->MB008, false); ?></td>
                            <td><?php echo e($b4_shipback->MB006, false); ?></td>
                            <td><?php echo e($b4_shipback->MA038, false); ?></td>
                            <td><?php echo e($b4_shipback->MA019, false); ?></td>
                            <td><?php echo e($b4_shipback->TJ005, false); ?></td>
                            <td><?php echo e($b4_shipback->TJ007, false); ?></td>
                            <td><?php echo e($b4_shipback->TI009, false); ?></td>
                            <td><?php echo e($b4_shipback->TJ033, false); ?></td>
                            <td><?php echo e($b4_shipback->TJ034, false); ?></td>
                            <td><?php echo e($b4_shipback->TJ001, false); ?></td>
                            <td><?php echo e($b4_shipback->TJ002, false); ?></td>
                            <td><?php echo e($b4_shipback->TJ003, false); ?></td>
                        </tr>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
            </div>            

        </div>
    </div>


    </div>
</div>

<script>
 function jsTabs(evt, tabId) {
    var tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabs-panel");
    for (var i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
     }
     tablinks = document.getElementsByClassName("tabs-menu");
     for (var i = 0; i < tablinks.length; i++) {
       tablinks[i].className = tablinks[i].className.replace(" tabs-menu-active", "");
     }
     var tab = document.getElementById(tabId);
         tab.style.display = "block";
     evt.currentTarget.className += " tabs-menu-active";
     return false;
 }
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/finance/fin_b4chk.blade.php ENDPATH**/ ?>