<?php $__env->startSection('title','查詢系統'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <h5>查詢結果</h5>
        <p><a href=<?php echo e(route('searchs.search2')); ?> class="btn btn-success btn-sm">返回</a></p>
        </div>
        <div class="col-12 table-cont" id="table-cont">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>客戶代碼</th>
                        <th>客戶全名</th>
                        <th>銷貨日期</th>
                        <th>部門</th>
                        <th>品牌</th>
                        <th>四大類</th>
                        <th>品號</th>
                        <th>品名</th>
                        <th>數量</th>
                        <th>匯率\單位</th>
                        <th>發票起號</th>
                        <th>發票迄號</th>
                        <th>單別</th>
                        <th>單號</th>
                        <th>序號</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($inv->TG004); ?></td>
                        <td><?php echo e($inv->TG007); ?></td>
                        <td><?php echo e($inv->TG003); ?></td>
                        <td><?php echo e($inv->TG005); ?></td>
                        <td><?php echo e($inv->MB008); ?></td>
                        <td><?php echo e($inv->MB006); ?></td>
                        <td><?php echo e($inv->TH004); ?></td>
                        <td><?php echo e($inv->TH005); ?></td>
                        <td><?php echo e($inv->QTY); ?></td>
                        <td><?php echo e($inv->TG012); ?></td>
                        <td><?php echo e($inv->TG098); ?></td>
                        <td><?php echo e($inv->TG014); ?></td>
                        <td><?php echo e($inv->TH001); ?></td>
                        <td><?php echo e($inv->TH002); ?></td>
                        <td><?php echo e($inv->TH003); ?></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/searchs/pos_inv.blade.php ENDPATH**/ ?>