<?php $__env->startSection('title','Home!'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h2>Welcome! It's a test website!!</h2>
            <h2>Keep Going!!</h2>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/index.blade.php ENDPATH**/ ?>