<?php $__env->startSection('title','UserEdit'); ?>
<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<?php if(auth()->user()->user_level==9): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8"><br>
            <form method="post" action="<?php echo e(route('UsersProfile.UsersUpdate', $user->username), false); ?>">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('PATCH'), false); ?>

                <div class="card">
                    <div class="card-header">
                    使用者資訊
                </div>
                <div class="card-body">
                    <div class="shadow p-1 bg-white rounded"><label class="col-md-4 col-form-label text-md-right">Login-ID：</label><input type="text" name="username" value="<?php echo e($user->username, false); ?>" readonly><label style="font-size:10px">(ReadOnly無法修改)</label></div>
                    <div class="shadow p-1 bg-white rounded"><label class="col-md-4 col-form-label text-md-right">Name：</label>
                    <input type="text" name="name" value="<?php echo e($user->name, false); ?>"></div>
                    <div class="shadow p-1 bg-white rounded"><label class="col-md-4 col-form-label text-md-right">User Level：</label>
                    <input type="text" name="user_level" value="<?php echo e($user->user_level, false); ?>"></div>
                    <div class="shadow p-1 bg-white rounded"><label class="col-md-4 col-form-label text-md-right">E-mail：</label>
                    <input type="text" name="email" value="<?php echo e($user->email, false); ?>"></div>
                </div>
                <label style="font-size:10px">## 註:User Level權限預設=0；1-行政；2-業務；3-生產；4-研發；5-財務；9系統管理員。 ##</label>
                <div><br>
                <a href="<?php echo e(route('UsersProfile.UsersIndex'), false); ?>" class="btn btn-secondary btn-sm">返回</a>
                <button type="submit" class="btn btn-primary btn-sm" onclick="return confirm('是否確認儲存?');">儲存</button>
                </div>
            </form>
        </div>
    </div>
</div> 
<?php endif; ?>
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/UsersProfile/UsersEdit.blade.php ENDPATH**/ ?>