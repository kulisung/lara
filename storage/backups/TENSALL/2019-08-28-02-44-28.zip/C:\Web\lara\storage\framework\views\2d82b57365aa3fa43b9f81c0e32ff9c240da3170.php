<?php $__env->startSection('title','UsersList'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <h5>使用者列表</h5>
        </div>
        <br>
        <div class="col-12 table-cont" id="table-cont">
            <br>
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>Login-ID</th>
                        <th>Name</th>
                        <th>User-Level</th>
                        <th>E-mail</th>
                        <th>Edit</th>
                        <th>Reset Password</th>
                        <th>Delete User</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->username, false); ?></td>
                        <td><?php echo e($user->name, false); ?></td>
                        <td><?php echo e($user->user_level, false); ?></td>
                        <td><?php echo e($user->email, false); ?></td>
                        <td>
                            <a href="<?php echo e(route('UsersProfile.UsersEdit',$user->username), false); ?>" style="font-size:12px" class="btn btn-primary btn-sm">Edit</a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('UsersProfile.UsersResetPWD',$user->username), false); ?>" class="btn btn-primary btn-sm" style="font-size:12px">ResetPassword</a>
                        </td>
                        <td>
                            <form method="post" action="<?php echo e(route('UsersProfile.destroy',$user->username), false); ?>" id='delete'>
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('DELETE'), false); ?>

                                <button type="submit" style="font-size:12px" class="btn btn-danger btn-sm" onclick="return confirm('是否確認刪除?');">Delete</button>
                            </form>
                        </td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/UsersProfile/UsersIndex.blade.php ENDPATH**/ ?>