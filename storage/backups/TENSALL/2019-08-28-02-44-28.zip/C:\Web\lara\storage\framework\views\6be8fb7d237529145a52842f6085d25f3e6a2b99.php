<?php

//require '../vendor/autoload.php';  //Laravel 已自動載入Auto項目，無需寫此行

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

$spreadsheet = new Spreadsheet();  // 開新檔案
$worksheet = $spreadsheet->getActiveSheet(); 
$worksheet->setTitle('進貨單資料明細');

$worksheet->setCellValueByColumnAndRow(1, 1, '進貨單別');
$worksheet->setCellValueByColumnAndRow(2, 1, '進貨單號');
$worksheet->setCellValueByColumnAndRow(3, 1, '進貨序號');
$worksheet->setCellValueByColumnAndRow(4, 1, '進貨品號');
$worksheet->setCellValueByColumnAndRow(5, 1, '進貨數量');
$worksheet->setCellValueByColumnAndRow(6, 1, '合計已退貨數量');

//$productid = $request->input('TH004').'%';
$res = DB::connection('sqlsrv_atv0002')->select('select TH001,TH002,TH003,TH004,TH007,SUM(TJ009) as SUMQTY from PURTH LEFT JOIN PURTJ ON PURTH.TH002=PURTJ.TJ014 and PURTH.TH003=PURTJ.TJ015 and PURTJ.TJ020=? WHERE TH030=? AND TH004 like ? GROUP BY TH001,TH002,TH003,TH004,TH007 ORDER BY TH002 DESC,TH003',['Y', 'Y', 'A-B013%']);

$i=2;
        foreach ($res as $data) {
            $i++;
            $worksheet->setCellValue('A' . $i, $data['TH001']);
            $worksheet->setCellValue('B' . $i, $data['TH002']);
            $worksheet->setCellValue('C' . $i, $data['TH003']);
            $worksheet->setCellValue('D' . $i, $data['TH004']);
            $worksheet->setCellValue('E' . $i, $data['TH005']);
            $worksheet->setCellValue('F' . $i, $data['SUMQTY']);
            
        }


    // 下载
$filename = '進退貨彙總.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="'.$filename.'"');
header('Cache-Control: max-age=0');

$writer = \PhpOffice\PhpSpreadsheet\IOFactory::createWriter($spreadsheet, 'Xlsx');
$writer->save('php://output');

//$writer = new Xlsx($spreadsheet);
//$writer->save('test.xlsx');
?><?php /**PATH C:\Web\lara\resources\views/auth/excel.blade.php ENDPATH**/ ?>