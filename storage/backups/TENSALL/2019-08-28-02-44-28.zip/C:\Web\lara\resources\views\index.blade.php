@extends('layouts.master')
@section('title','Home!')
@section('content')
<div class="container">
    <div class="row">
        <div class="col-12">
            <h2>Welcome! It's a test website!!</h2>
            <h2>Keep Going!!</h2>
        </div>
    </div>
</div>  
@endsection