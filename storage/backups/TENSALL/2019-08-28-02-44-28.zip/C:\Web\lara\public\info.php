<?php
  phpinfo()
?>