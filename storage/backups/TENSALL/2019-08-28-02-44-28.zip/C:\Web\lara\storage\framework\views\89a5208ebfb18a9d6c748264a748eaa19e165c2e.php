<?php $__env->startSection('title','資料庫連結測試'); ?>
<?php $__env->startSection('content'); ?>
<?php
$serverName = "192.168.11.103"; //serverName\instanceName
$connectionInfo = array( "Database"=>"ATV0002", "UID"=>"sa", "PWD"=>"dsc@16725493", "CharacterSet" => "UTF-8");
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn ) {
     echo "Connection established.連線成功!!<br />";
}else{
     echo "Connection could not be established.連結失敗!?<br />";
     die( print_r( sqlsrv_errors(), true));
}
// Close the connection.
sqlsrv_close($conn);
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/auth/result.blade.php ENDPATH**/ ?>