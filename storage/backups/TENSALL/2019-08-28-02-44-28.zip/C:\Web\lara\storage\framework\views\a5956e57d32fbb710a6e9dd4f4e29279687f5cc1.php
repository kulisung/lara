<?php $__env->startSection('title','結帳前查詢'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <h2>結帳前查詢</h2>
            <a class="btn btn-primary" href=<?php echo e(route('outputexcel')); ?> role="button">產出Excel</a>
            <a class="btn btn-primary" href=<?php echo e(route('excel')); ?> role="button">Excel匯出測試</a>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/auth/export.blade.php ENDPATH**/ ?>