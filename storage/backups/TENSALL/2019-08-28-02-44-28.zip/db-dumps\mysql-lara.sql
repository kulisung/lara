
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_menu` WRITE;
/*!40000 ALTER TABLE `admin_menu` DISABLE KEYS */;
INSERT INTO `admin_menu` VALUES (1,0,1,'首頁','fa-bar-chart','/',NULL,NULL,'2019-08-07 22:42:50'),(2,0,2,'Administrator','fa-tasks',NULL,NULL,NULL,'2019-08-21 18:40:33'),(3,2,3,'AdminUsers','fa-users','auth/users',NULL,NULL,'2019-08-21 18:40:53'),(4,2,4,'Roles','fa-user','auth/roles',NULL,NULL,NULL),(5,2,5,'Permission','fa-ban','auth/permissions',NULL,NULL,NULL),(6,2,6,'Menu','fa-bars','auth/menu',NULL,NULL,NULL),(7,2,7,'Operation log','fa-history','auth/logs',NULL,NULL,NULL),(8,10,0,'User_Profile','fa-users','/users',NULL,'2019-08-11 23:29:51','2019-08-12 00:58:55'),(10,6,0,'UsersManagement','fa-bars','/users',NULL,'2019-08-12 00:57:48','2019-08-21 20:58:02');
/*!40000 ALTER TABLE `admin_menu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_operation_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_operation_log_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_operation_log` WRITE;
/*!40000 ALTER TABLE `admin_operation_log` DISABLE KEYS */;
INSERT INTO `admin_operation_log` VALUES (1,1,'admin','GET','::1','[]','2019-08-07 22:24:10','2019-08-07 22:24:10'),(2,1,'admin','GET','::1','[]','2019-08-07 22:28:47','2019-08-07 22:28:47'),(3,1,'admin/auth/logout','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-07 22:28:54','2019-08-07 22:28:54'),(4,1,'admin','GET','::1','[]','2019-08-07 22:29:12','2019-08-07 22:29:12'),(5,1,'admin','GET','::1','[]','2019-08-07 22:39:38','2019-08-07 22:39:38'),(6,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-07 22:41:28','2019-08-07 22:41:28'),(7,1,'admin/auth/menu/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-07 22:41:34','2019-08-07 22:41:34'),(8,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-07 22:42:17','2019-08-07 22:42:17'),(9,1,'admin/auth/menu/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-07 22:42:32','2019-08-07 22:42:32'),(10,1,'admin/auth/menu/1','PUT','::1','{\"parent_id\":\"0\",\"title\":\"\\u9996\\u9801\",\"icon\":\"fa-bar-chart\",\"uri\":\"\\/\",\"roles\":[null],\"permission\":null,\"_token\":\"6LiUD0UmPum3NlFVHK1g20iaYbxEzg6AGIYZuzzr\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-07 22:42:50','2019-08-07 22:42:50'),(11,1,'admin/auth/menu','GET','::1','[]','2019-08-07 22:42:50','2019-08-07 22:42:50'),(12,1,'admin/auth/permissions','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-07 22:55:03','2019-08-07 22:55:03'),(13,1,'admin','GET','::1','[]','2019-08-11 23:17:49','2019-08-11 23:17:49'),(14,1,'admin/auth/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:18:08','2019-08-11 23:18:08'),(15,1,'admin/auth/users/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:18:14','2019-08-11 23:18:14'),(16,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:28:01','2019-08-11 23:28:01'),(17,1,'admin/auth/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:28:05','2019-08-11 23:28:05'),(18,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:28:20','2019-08-11 23:28:20'),(19,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:28:36','2019-08-11 23:28:36'),(20,1,'admin/auth/menu','POST','::1','{\"parent_id\":\"0\",\"title\":\"user-management\",\"icon\":\"fa-users\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"grAvjQT11HbzILRMNDUuV4C05vfmBt6zfkoimVgt\"}','2019-08-11 23:29:51','2019-08-11 23:29:51'),(21,1,'admin/auth/menu','GET','::1','[]','2019-08-11 23:29:52','2019-08-11 23:29:52'),(22,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:30:09','2019-08-11 23:30:09'),(23,1,'admin/users/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:32:21','2019-08-11 23:32:21'),(24,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-11 23:32:41','2019-08-11 23:32:41'),(25,1,'admin/users','GET','::1','[]','2019-08-12 00:11:35','2019-08-12 00:11:35'),(26,1,'admin/users','GET','::1','[]','2019-08-12 00:11:40','2019-08-12 00:11:40'),(27,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:11:50','2019-08-12 00:11:50'),(28,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:11:57','2019-08-12 00:11:57'),(29,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:12:00','2019-08-12 00:12:00'),(30,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:12:04','2019-08-12 00:12:04'),(31,1,'admin/users/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:12:13','2019-08-12 00:12:13'),(32,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:12:27','2019-08-12 00:12:27'),(33,1,'admin/users','GET','::1','[]','2019-08-12 00:13:41','2019-08-12 00:13:41'),(34,1,'admin/users/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:47:06','2019-08-12 00:47:06'),(35,1,'admin/users/1','PUT','::1','{\"username\":\"bryan\",\"name\":\"Bryan\",\"user_level\":\"0\",\"email\":null,\"password\":null,\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-12 00:47:15','2019-08-12 00:47:15'),(36,1,'admin/users/1/edit','GET','::1','[]','2019-08-12 00:47:16','2019-08-12 00:47:16'),(37,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:48:05','2019-08-12 00:48:05'),(38,1,'admin/users/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:48:16','2019-08-12 00:48:16'),(39,1,'admin/users/1','PUT','::1','{\"username\":\"bryan\",\"name\":\"Bryan\",\"user_level\":\"0\",\"email\":null,\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-12 00:48:22','2019-08-12 00:48:22'),(40,1,'admin/users','GET','::1','[]','2019-08-12 00:48:23','2019-08-12 00:48:23'),(41,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:49:59','2019-08-12 00:49:59'),(42,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:50:04','2019-08-12 00:50:04'),(43,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:50:13','2019-08-12 00:50:13'),(44,1,'admin/auth/menu','POST','::1','{\"parent_id\":\"0\",\"title\":\"User_Reset_Password\",\"icon\":\"fa-users\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\"}','2019-08-12 00:56:36','2019-08-12 00:56:36'),(45,1,'admin/auth/menu','GET','::1','[]','2019-08-12 00:56:36','2019-08-12 00:56:36'),(46,1,'admin/auth/menu/2/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:56:52','2019-08-12 00:56:52'),(47,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:57:07','2019-08-12 00:57:07'),(48,1,'admin/auth/menu/3/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:57:12','2019-08-12 00:57:12'),(49,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:57:20','2019-08-12 00:57:20'),(50,1,'admin/auth/menu','POST','::1','{\"parent_id\":\"0\",\"title\":\"Users\",\"icon\":\"fa-bars\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\"}','2019-08-12 00:57:48','2019-08-12 00:57:48'),(51,1,'admin/auth/menu','GET','::1','[]','2019-08-12 00:57:48','2019-08-12 00:57:48'),(52,1,'admin/auth/menu/8/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:57:51','2019-08-12 00:57:51'),(53,1,'admin/auth/menu/8','PUT','::1','{\"parent_id\":\"3\",\"title\":\"User_Profile\",\"icon\":\"fa-users\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-12 00:58:23','2019-08-12 00:58:23'),(54,1,'admin/auth/menu','GET','::1','[]','2019-08-12 00:58:23','2019-08-12 00:58:23'),(55,1,'admin/auth/menu/8/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:58:40','2019-08-12 00:58:40'),(56,1,'admin/auth/menu/8','PUT','::1','{\"parent_id\":\"10\",\"title\":\"User_Profile\",\"icon\":\"fa-users\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-12 00:58:55','2019-08-12 00:58:55'),(57,1,'admin/auth/menu','GET','::1','[]','2019-08-12 00:58:56','2019-08-12 00:58:56'),(58,1,'admin/auth/menu/9/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:59:04','2019-08-12 00:59:04'),(59,1,'admin/auth/menu/9','PUT','::1','{\"parent_id\":\"10\",\"title\":\"Reset_Password\",\"icon\":\"fa-users\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-12 00:59:18','2019-08-12 00:59:18'),(60,1,'admin/auth/menu','GET','::1','[]','2019-08-12 00:59:18','2019-08-12 00:59:18'),(61,1,'admin/auth/menu/10/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 00:59:27','2019-08-12 00:59:27'),(62,1,'admin/auth/menu/10','PUT','::1','{\"parent_id\":\"0\",\"title\":\"UsersManagement\",\"icon\":\"fa-bars\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-12 00:59:44','2019-08-12 00:59:44'),(63,1,'admin/auth/menu','GET','::1','[]','2019-08-12 00:59:45','2019-08-12 00:59:45'),(64,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:00:04','2019-08-12 01:00:04'),(65,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:00:08','2019-08-12 01:00:08'),(66,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:00:11','2019-08-12 01:00:11'),(67,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:00:14','2019-08-12 01:00:14'),(68,1,'admin/auth/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:00:18','2019-08-12 01:00:18'),(69,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:00:20','2019-08-12 01:00:20'),(70,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:00:26','2019-08-12 01:00:26'),(71,1,'admin/users/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:00:57','2019-08-12 01:00:57'),(72,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:01:02','2019-08-12 01:01:02'),(73,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:01:10','2019-08-12 01:01:10'),(74,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:01:15','2019-08-12 01:01:15'),(75,1,'admin/users/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:01:25','2019-08-12 01:01:25'),(76,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:01:37','2019-08-12 01:01:37'),(77,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:01:40','2019-08-12 01:01:40'),(78,1,'admin/auth/menu','GET','::1','[]','2019-08-12 01:03:01','2019-08-12 01:03:01'),(79,1,'admin/auth/menu/9','DELETE','::1','{\"_method\":\"delete\",\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\"}','2019-08-12 01:03:25','2019-08-12 01:03:25'),(80,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:03:26','2019-08-12 01:03:26'),(81,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:03:42','2019-08-12 01:03:42'),(82,1,'admin/users/29/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:03:47','2019-08-12 01:03:47'),(83,1,'admin/users/29','PUT','::1','{\"username\":\"123\",\"name\":\"bryan\",\"user_level\":\"999\",\"email\":\"1qa@1qa\",\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-12 01:03:53','2019-08-12 01:03:53'),(84,1,'admin/users/29/edit','GET','::1','[]','2019-08-12 01:03:54','2019-08-12 01:03:54'),(85,1,'admin/users/29','PUT','::1','{\"username\":\"123\",\"name\":\"bryan\",\"user_level\":\"99\",\"email\":\"1qa@1qa\",\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\"}','2019-08-12 01:04:06','2019-08-12 01:04:06'),(86,1,'admin/users','GET','::1','[]','2019-08-12 01:04:07','2019-08-12 01:04:07'),(87,1,'admin/users/27/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:06:39','2019-08-12 01:06:39'),(88,1,'admin/users/27','PUT','::1','{\"username\":\"mis\",\"name\":\"Bryan\",\"user_level\":\"99\",\"email\":\"bryan@tensall.com.tw\",\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-12 01:06:45','2019-08-12 01:06:45'),(89,1,'admin/users','GET','::1','[]','2019-08-12 01:06:46','2019-08-12 01:06:46'),(90,1,'admin/users/29','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:06:50','2019-08-12 01:06:50'),(91,1,'admin/users/29/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:07:00','2019-08-12 01:07:00'),(92,1,'admin/users/29','DELETE','::1','{\"_method\":\"delete\",\"_token\":\"agmI0zwE8KWoajCxUSq0lL1605tA48yEAbWDAI4v\"}','2019-08-12 01:07:05','2019-08-12 01:07:05'),(93,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:07:06','2019-08-12 01:07:06'),(94,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:10:33','2019-08-12 01:10:33'),(95,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:12:52','2019-08-12 01:12:52'),(96,1,'admin/auth/setting','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:14:41','2019-08-12 01:14:41'),(97,1,'admin/auth/setting','PUT','::1','{\"name\":\"Administrator\",\"password\":\"$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K\",\"password_confirmation\":\"$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K\",\"_token\":\"cslAOTZgBEXs9Yssakz4uI0OSlFfNxtsdwHcpVWl\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-12 01:16:36','2019-08-12 01:16:36'),(98,1,'admin/auth/setting','GET','::1','[]','2019-08-12 01:16:37','2019-08-12 01:16:37'),(99,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:16:49','2019-08-12 01:16:49'),(100,1,'admin','GET','::1','[]','2019-08-12 01:16:52','2019-08-12 01:16:52'),(101,1,'admin/auth/setting','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:17:02','2019-08-12 01:17:02'),(102,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:18:30','2019-08-12 01:18:30'),(103,1,'admin','GET','::1','[]','2019-08-12 01:18:34','2019-08-12 01:18:34'),(104,1,'admin','GET','::1','[]','2019-08-12 01:18:42','2019-08-12 01:18:42'),(105,1,'admin','GET','::1','[]','2019-08-12 01:18:44','2019-08-12 01:18:44'),(106,1,'admin/auth/setting','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:18:59','2019-08-12 01:18:59'),(107,1,'admin','GET','::1','[]','2019-08-12 01:20:15','2019-08-12 01:20:15'),(108,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:20:19','2019-08-12 01:20:19'),(109,1,'admin/auth/setting','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:20:27','2019-08-12 01:20:27'),(110,1,'admin/auth/setting','PUT','::1','{\"name\":\"Administrator\",\"password\":\"$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K\",\"password_confirmation\":\"$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K\",\"_token\":\"cslAOTZgBEXs9Yssakz4uI0OSlFfNxtsdwHcpVWl\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\"}','2019-08-12 01:21:07','2019-08-12 01:21:07'),(111,1,'admin/auth/setting','GET','::1','[]','2019-08-12 01:21:08','2019-08-12 01:21:08'),(112,1,'admin/auth/setting','PUT','::1','{\"name\":\"Administrator\",\"password\":\"$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K\",\"password_confirmation\":\"$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K\",\"_token\":\"cslAOTZgBEXs9Yssakz4uI0OSlFfNxtsdwHcpVWl\",\"_method\":\"PUT\"}','2019-08-12 01:33:04','2019-08-12 01:33:04'),(113,1,'admin/auth/setting','GET','::1','[]','2019-08-12 01:33:05','2019-08-12 01:33:05'),(114,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:33:33','2019-08-12 01:33:33'),(115,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:38:19','2019-08-12 01:38:19'),(116,1,'admin/auth/setting','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:38:22','2019-08-12 01:38:22'),(117,1,'admin/auth/setting','PUT','::1','{\"name\":\"Administrator\",\"password\":\"$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K\",\"password_confirmation\":\"$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K\",\"_token\":\"cslAOTZgBEXs9Yssakz4uI0OSlFfNxtsdwHcpVWl\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\"}','2019-08-12 01:39:04','2019-08-12 01:39:04'),(118,1,'admin/auth/setting','GET','::1','[]','2019-08-12 01:39:04','2019-08-12 01:39:04'),(119,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-12 01:39:12','2019-08-12 01:39:12'),(120,1,'admin','GET','::1','[]','2019-08-12 01:39:16','2019-08-12 01:39:16'),(121,1,'admin','GET','::1','[]','2019-08-21 16:17:58','2019-08-21 16:17:58'),(122,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:18:05','2019-08-21 16:18:05'),(123,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:18:13','2019-08-21 16:18:13'),(124,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:18:16','2019-08-21 16:18:16'),(125,1,'admin/users','POST','::1','{\"username\":\"test\",\"name\":\"tester\",\"user_level\":\"0\",\"email\":\"test@test\",\"password\":\"123456\",\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 16:18:55','2019-08-21 16:18:55'),(126,1,'admin/users','GET','::1','[]','2019-08-21 16:18:56','2019-08-21 16:18:56'),(127,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:22:18','2019-08-21 16:22:18'),(128,1,'admin/users','GET','::1','[]','2019-08-21 16:22:20','2019-08-21 16:22:20'),(129,1,'admin/users','GET','::1','[]','2019-08-21 16:23:05','2019-08-21 16:23:05'),(130,1,'admin/users/28/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:23:12','2019-08-21 16:23:12'),(131,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:23:26','2019-08-21 16:23:26'),(132,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:24:52','2019-08-21 16:24:52'),(133,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:24:56','2019-08-21 16:24:56'),(134,1,'admin/users/28/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:25:30','2019-08-21 16:25:30'),(135,1,'admin/users/28','PUT','::1','{\"username\":\"test\",\"name\":\"tester\",\"user_level\":\"0\",\"email\":\"test@test\",\"$2y$10$NrShQF736lzLG9jb\\/BYreuv79\\/qhG2JmMUHoVBJvwuXtsbQ\\/aYrFO\":\"123456\",\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 16:25:38','2019-08-21 16:25:38'),(136,1,'admin/users','GET','::1','[]','2019-08-21 16:25:38','2019-08-21 16:25:38'),(137,1,'admin/users/28/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:27:29','2019-08-21 16:27:29'),(138,1,'admin/users/28','PUT','::1','{\"username\":\"test\",\"name\":\"tester\",\"user_level\":\"0\",\"email\":\"test@test\",\"$2y$10$QlktLb\":{\"fdB\":{\"Bi6nXctOZdu0jSRb8JO51O8MV9ZpNGlauPyuKySxMC\":\"123456\"}},\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 16:27:34','2019-08-21 16:27:34'),(139,1,'admin/users','GET','::1','[]','2019-08-21 16:27:35','2019-08-21 16:27:35'),(140,1,'admin/_handle_action_','POST','::1','{\"_key\":\"28\",\"_model\":\"App_User\",\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}','2019-08-21 16:29:20','2019-08-21 16:29:20'),(141,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:29:20','2019-08-21 16:29:20'),(142,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:29:22','2019-08-21 16:29:22'),(143,1,'admin/users','POST','::1','{\"username\":\"tester\",\"name\":\"tester\",\"user_level\":\"0\",\"email\":null,\"$2y$10$6Wd\\/069Pk8GYvkWFoTohDe16QUDECaDI50zLA78L8tTcjgE6Y7fo\":[\"123456\"],\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 16:29:46','2019-08-21 16:29:46'),(144,1,'admin/users/create','GET','::1','[]','2019-08-21 16:29:47','2019-08-21 16:29:47'),(145,1,'admin/users','POST','::1','{\"username\":\"tester\",\"name\":\"tester\",\"user_level\":\"0\",\"email\":\"test@test\",\"$2y$10$TKgdrFvxIdTTcVby9TYGNOqyIPxbdmJq5\":{\"FsaIFgYTgbnz122n5VS\":\"123456\"},\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\"}','2019-08-21 16:33:25','2019-08-21 16:33:25'),(146,1,'admin/users/create','GET','::1','[]','2019-08-21 16:33:26','2019-08-21 16:33:26'),(147,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:33:39','2019-08-21 16:33:39'),(148,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:33:48','2019-08-21 16:33:48'),(149,1,'admin/users','POST','::1','{\"username\":\"ttt\",\"name\":\"tester\",\"user_level\":null,\"email\":\"test@test\",\"$2y$10$pmqW9CmIoIUMh16JVtGHoeqkZtcQOUnpRDMAnZ6r81VJ0rl2H20mS\":\"123456\",\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 16:34:31','2019-08-21 16:34:31'),(150,1,'admin/users/create','GET','::1','[]','2019-08-21 16:34:31','2019-08-21 16:34:31'),(151,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 16:35:22','2019-08-21 16:35:22'),(152,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:33:49','2019-08-21 18:33:49'),(153,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:33:58','2019-08-21 18:33:58'),(154,1,'admin/users','POST','::1','{\"username\":\"test\",\"name\":\"tester\",\"user_level\":null,\"email\":\"test@test\",\"$2y$10$g6SzX84MFa6cHf8Menc4Ie2oawvn2TIC\":{\"MT\\/hWakcqW9Q1neRjrni\":\"1qaz2wsx\"},\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 18:34:52','2019-08-21 18:34:52'),(155,1,'admin/users/create','GET','::1','[]','2019-08-21 18:34:53','2019-08-21 18:34:53'),(156,1,'admin/auth/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:39:11','2019-08-21 18:39:11'),(157,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:39:18','2019-08-21 18:39:18'),(158,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:39:27','2019-08-21 18:39:27'),(159,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:39:29','2019-08-21 18:39:29'),(160,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:39:32','2019-08-21 18:39:32'),(161,1,'admin/auth/menu/3/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:39:45','2019-08-21 18:39:45'),(162,1,'admin/auth/menu/3','PUT','::1','{\"parent_id\":\"2\",\"title\":\"BackendUsers\",\"icon\":\"fa-users\",\"uri\":\"auth\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-21 18:40:06','2019-08-21 18:40:06'),(163,1,'admin/auth/menu','GET','::1','[]','2019-08-21 18:40:06','2019-08-21 18:40:06'),(164,1,'admin/auth/menu/2/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:40:25','2019-08-21 18:40:25'),(165,1,'admin/auth/menu/2','PUT','::1','{\"parent_id\":\"0\",\"title\":\"Administrator\",\"icon\":\"fa-tasks\",\"uri\":null,\"roles\":[\"1\",null],\"permission\":null,\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-21 18:40:33','2019-08-21 18:40:33'),(166,1,'admin/auth/menu','GET','::1','[]','2019-08-21 18:40:33','2019-08-21 18:40:33'),(167,1,'admin/auth/menu','GET','::1','[]','2019-08-21 18:40:37','2019-08-21 18:40:37'),(168,1,'admin/auth/menu/3/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 18:40:45','2019-08-21 18:40:45'),(169,1,'admin/auth/menu/3','PUT','::1','{\"parent_id\":\"2\",\"title\":\"AdminUsers\",\"icon\":\"fa-users\",\"uri\":\"auth\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"ilbXk0h2sgFUBY9pF5XDtltJGxiisoORYBlSsqCn\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-21 18:40:53','2019-08-21 18:40:53'),(170,1,'admin/auth/menu','GET','::1','[]','2019-08-21 18:40:53','2019-08-21 18:40:53'),(171,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 20:30:15','2019-08-21 20:30:15'),(172,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 20:57:27','2019-08-21 20:57:27'),(173,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 20:57:31','2019-08-21 20:57:31'),(174,1,'admin/auth/menu','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 20:57:34','2019-08-21 20:57:34'),(175,1,'admin/auth/menu/10/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 20:57:53','2019-08-21 20:57:53'),(176,1,'admin/auth/menu/10','PUT','::1','{\"parent_id\":\"6\",\"title\":\"UsersManagement\",\"icon\":\"fa-bars\",\"uri\":\"\\/users\",\"roles\":[null],\"permission\":null,\"_token\":\"fdQ3rs3TSGgA6HBllGXBpY86M3PAWDXWR0WbzfsT\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/auth\\/menu\"}','2019-08-21 20:58:01','2019-08-21 20:58:01'),(177,1,'admin/auth/menu','GET','::1','[]','2019-08-21 20:58:02','2019-08-21 20:58:02'),(178,1,'admin/auth/menu','GET','::1','[]','2019-08-21 20:58:05','2019-08-21 20:58:05'),(179,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:02:11','2019-08-21 21:02:11'),(180,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:02:31','2019-08-21 21:02:31'),(181,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:02:36','2019-08-21 21:02:36'),(182,1,'admin/users/1/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:02:42','2019-08-21 21:02:42'),(183,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:03:04','2019-08-21 21:03:04'),(184,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:14:21','2019-08-21 21:14:21'),(185,1,'admin/users/29/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:14:27','2019-08-21 21:14:27'),(186,1,'admin/users/29','PUT','::1','{\"username\":\"test\",\"name\":\"tester\",\"user_level\":\"0\",\"email\":\"test@test\",\"$2y$10$\":{\"nacBXhV\\/e0oxoFM\\/HLGpurlbAaA9LQUUXZjAJ80DXCZCm9WOxzCG\":\"1qaz2wsx\"},\"_token\":\"fdQ3rs3TSGgA6HBllGXBpY86M3PAWDXWR0WbzfsT\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 21:14:36','2019-08-21 21:14:36'),(187,1,'admin/users','GET','::1','[]','2019-08-21 21:14:37','2019-08-21 21:14:37'),(188,1,'admin/users/29/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:15:29','2019-08-21 21:15:29'),(189,1,'admin/users/29','PUT','::1','{\"username\":\"test\",\"name\":\"tester\",\"user_level\":\"0\",\"email\":\"test@test\",\"$2y$10$LAfyfiOf8CTpYLvQT19UO\":{\"kHWZRaWxgdbQZCZxkbVcWkZ1qLmzC3e\":\"zxcvbn\"},\"_token\":\"iFRELFSoql4AInvuBZHqJsCDjPxNzDGe3IUVeLpu\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 21:15:41','2019-08-21 21:15:41'),(190,1,'admin/users','GET','::1','[]','2019-08-21 21:15:41','2019-08-21 21:15:41'),(191,1,'admin/users/29/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:20:37','2019-08-21 21:20:37'),(192,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:29:34','2019-08-21 21:29:34'),(193,1,'admin/users/29/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:29:38','2019-08-21 21:29:38'),(194,1,'admin/users/29','PUT','::1','{\"username\":\"test\",\"name\":\"tester\",\"user_level\":\"0\",\"email\":\"test@test\",\"password\":\"zxcvbn\",\"_token\":\"luJiRAq89nyz9efg0Il8FtKirPQFyRLpZUFHVj1J\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 21:29:48','2019-08-21 21:29:48'),(195,1,'admin/users','GET','::1','[]','2019-08-21 21:29:48','2019-08-21 21:29:48'),(196,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:30:31','2019-08-21 21:30:31'),(197,1,'admin/users','POST','::1','{\"username\":\"bbb\",\"name\":\"bbb\",\"user_level\":null,\"email\":\"bbb@bbb\",\"password\":\"123456\",\"_token\":\"HnISA9YUyRboYK45EJk4aumEVkBPzFinFYsHyYjf\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 21:30:52','2019-08-21 21:30:52'),(198,1,'admin/users/create','GET','::1','[]','2019-08-21 21:30:53','2019-08-21 21:30:53'),(199,1,'admin/users','POST','::1','{\"username\":\"bbb\",\"name\":\"bbb\",\"user_level\":\"0\",\"email\":\"bbb@bbb\",\"password\":\"123456\",\"_token\":\"HnISA9YUyRboYK45EJk4aumEVkBPzFinFYsHyYjf\"}','2019-08-21 21:31:11','2019-08-21 21:31:11'),(200,1,'admin/users','GET','::1','[]','2019-08-21 21:31:11','2019-08-21 21:31:11'),(201,1,'admin/users/30/edit','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-21 21:31:52','2019-08-21 21:31:52'),(202,1,'admin/users/30','PUT','::1','{\"username\":\"bbb\",\"name\":\"bbb\",\"user_level\":\"0\",\"email\":\"bbb@bbb\",\"password\":\"1qaz2wsx\",\"_token\":\"SUeDOCyJ5uKgt94mmmL0QF4pOXbrFvEIoGxztoh6\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-21 21:32:00','2019-08-21 21:32:00'),(203,1,'admin/users','GET','::1','[]','2019-08-21 21:32:01','2019-08-21 21:32:01'),(204,1,'admin','GET','::1','[]','2019-08-22 16:18:01','2019-08-22 16:18:01'),(205,1,'admin','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-23 00:16:04','2019-08-23 00:16:04'),(206,1,'admin/users','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-23 00:16:14','2019-08-23 00:16:14'),(207,1,'admin/users/create','GET','::1','{\"_pjax\":\"#pjax-container\"}','2019-08-23 00:16:16','2019-08-23 00:16:16'),(208,1,'admin/users','POST','::1','{\"username\":\"aaa\",\"name\":\"aaa\",\"user_level\":\"0\",\"email\":\"aaa@aaa\",\"password\":\"1qaz2wsx\",\"_token\":\"DZIYbb4MW4g4SVwNxTtOiRxHfqouck5IY6wtHfhC\",\"after-save\":\"2\",\"_previous_\":\"http:\\/\\/lara.localhost\\/admin\\/users\"}','2019-08-23 00:16:41','2019-08-23 00:16:41'),(209,1,'admin/users/create','GET','::1','[]','2019-08-23 00:16:41','2019-08-23 00:16:41'),(210,1,'admin/users','POST','::1','{\"username\":\"bbb\",\"name\":\"bbb\",\"user_level\":\"0\",\"email\":\"bbb@bbb\",\"password\":\"1qaz2wsx\",\"_token\":\"DZIYbb4MW4g4SVwNxTtOiRxHfqouck5IY6wtHfhC\",\"after-save\":\"2\"}','2019-08-23 00:17:04','2019-08-23 00:17:04'),(211,1,'admin/users/create','GET','::1','[]','2019-08-23 00:17:05','2019-08-23 00:17:05'),(212,1,'admin/users','POST','::1','{\"username\":\"ccc\",\"name\":\"ccc\",\"user_level\":\"0\",\"email\":\"ccc@ccc\",\"password\":\"1qaz2wsx\",\"_token\":\"DZIYbb4MW4g4SVwNxTtOiRxHfqouck5IY6wtHfhC\"}','2019-08-23 00:17:17','2019-08-23 00:17:17'),(213,1,'admin/users','GET','::1','[]','2019-08-23 00:17:18','2019-08-23 00:17:18'),(214,1,'admin','GET','::1','[]','2019-08-27 16:14:42','2019-08-27 16:14:42'),(215,1,'admin','GET','::1','[]','2019-08-27 18:23:28','2019-08-27 18:23:28');
/*!40000 ALTER TABLE `admin_operation_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permissions_name_unique` (`name`),
  UNIQUE KEY `admin_permissions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_permissions` WRITE;
/*!40000 ALTER TABLE `admin_permissions` DISABLE KEYS */;
INSERT INTO `admin_permissions` VALUES (1,'All permission','*','','*',NULL,NULL),(2,'Dashboard','dashboard','GET','/',NULL,NULL),(3,'Login','auth.login','','/auth/login\r\n/auth/logout',NULL,NULL),(4,'User setting','auth.setting','GET,PUT','/auth/setting',NULL,NULL),(5,'Auth management','auth.management','','/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs',NULL,NULL);
/*!40000 ALTER TABLE `admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_menu` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_menu_role_id_menu_id_index` (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_role_menu` WRITE;
/*!40000 ALTER TABLE `admin_role_menu` DISABLE KEYS */;
INSERT INTO `admin_role_menu` VALUES (1,2,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_menu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_permissions_role_id_permission_id_index` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
INSERT INTO `admin_role_permissions` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_users_role_id_user_id_index` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_role_users` WRITE;
/*!40000 ALTER TABLE `admin_role_users` DISABLE KEYS */;
INSERT INTO `admin_role_users` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_name_unique` (`name`),
  UNIQUE KEY `admin_roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,'Administrator','administrator','2019-08-07 22:18:34','2019-08-07 22:18:34');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_user_permissions_user_id_permission_id_index` (`user_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_user_permissions` WRITE;
/*!40000 ALTER TABLE `admin_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$1.l0stYnnz7o.ObRd6YWPuEaneYH1V27lWJH7zLPU8Wq7YpBNUr0K','Administrator','images/Tensall-min-logo.jpg','mMOZwvydIehrr9BlpY0xzemcZQxfdlbR7KIHTjAizGWZdm3vkiCIh80pWtC2','2019-08-07 22:18:34','2019-08-12 01:39:04');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (9,'2014_10_12_000000_create_users_table',1),(10,'2014_10_12_100000_create_password_resets_table',1),(11,'2019_05_21_062728_add_username_to_users_table',1),(13,'2019_06_18_021709_create_posts_table',2),(14,'2016_01_04_173148_create_admin_tables',3),(18,'2019_08_12_075737_change_users_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('bryan@tensall.com.tw','$2y$10$r94ohEjjA7b6exVJZF4L2ePd37KQ081xLEHUotTDV6S5PwS7V//Gm','2019-08-21 18:24:45');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `user_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `views` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (7,'Test5','Haha5','bryan',0,'2019-07-04 17:24:03','2019-07-04 17:24:03'),(8,'Hi','HiHiHiHiHIHIHIHIHIHIH','bryan',0,'2019-08-02 05:42:33','2019-08-02 05:42:33'),(10,'測試','測試','admin',0,'2019-08-06 18:04:30','2019-08-06 18:04:30');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purth` (
  `TH001` int(4) DEFAULT NULL,
  `TH002` int(8) DEFAULT NULL,
  `TH003` int(2) DEFAULT NULL,
  `TH004` varchar(17) DEFAULT NULL,
  `TH007` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purth` WRITE;
/*!40000 ALTER TABLE `purth` DISABLE KEYS */;
INSERT INTO `purth` VALUES (3400,19010001,1,'A-B0131A01220001',25000),(3400,19010001,2,'A-B0131A00130008',38500),(3400,19010002,1,'BT0003A025100001',342),(3400,19010002,2,'BT0003B027030001',294),(3400,19010002,3,'BT0003D027114001',30),(3400,19010003,1,'A-B0131A00130004',40000),(3400,19010003,2,'A-B0131A00130005',30000),(3400,19010004,1,'A-B0131A02520001',25000),(3400,19010004,2,'A-B0131A02520001',3750),(3400,19010005,1,'A-B0131A00120003',25000),(3400,19010005,2,'A-B0131A01920002',24522),(3400,19010005,3,'A-B0131A01920002',3678),(3400,19010006,1,'A-B0131A00130004',70000),(3400,19010006,2,'A-B0131A00130005',40000),(3400,19010006,3,'A-B0131A00130006',10000),(3400,19010007,1,'B-T0003A015301001',3600),(3400,19010007,2,'BT0003A026104001',40),(3400,19010007,3,'BT0003A026104001',269),(3400,19010007,4,'BT0003A026104001',5691),(3400,19020001,1,'BT0003A025100001',342),(3400,19020001,2,'BT0003B027030001',312),(3400,19020001,3,'BT0003D027114001',3),(3400,19020001,4,'BT0003G037010001',2660),(3400,19020001,5,'BT0003D027114001',32),(3400,19030001,1,'BT0003A025100001',204),(3400,19030001,2,'BT0003B027030001',48),(3400,19030001,3,'BT0003G037010001',100),(3400,19030001,4,'BT0003A025100001',138),(3400,19030001,5,'BT0003B027030001',66),(3400,19030001,6,'BT0003B027030001',96),(3400,19030002,1,'A-B0131A00130001',17000),(3400,19030002,2,'A-B0131A00130001',2550),(3400,19030003,1,'A-B0131A00130008',38500),(3400,19040001,1,'B-T0003B027116001',40),(3400,19040001,2,'B-T0003B027116001',203),(3400,19040001,3,'BT0003A025100001',342),(3400,19040001,4,'BT0003B027030001',342),(3400,19040001,5,'BT0003G037010001',620),(3400,19040001,6,'BT0003G037010001',115),(3400,19040001,7,'PK-BT10051',20),(3400,19040001,8,'B-T0003B027116001',717),(3400,19040001,9,'PK-BT10051',172),(3400,19040001,10,'BT0003A025100001',84),(3400,19050001,1,'B-T0003B027116001',95),(3400,19050001,2,'BT0003A025100001',204),(3400,19050001,3,'BT0003B027030001',186),(3400,19050001,4,'BT0003G037010001',595),(3400,19050001,5,'PK-BT10051',19);
/*!40000 ALTER TABLE `purth` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_level` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (27,'mis','MIS','9','mis@mis',NULL,'$2y$10$YKCsmERB5hY0sKbYkEgmMudwfy0DRLolPVuQIN6hPOZyC7Fps9X9O',NULL,'2019-08-11 23:14:44','2019-08-26 21:44:33'),(32,'bbb','bbb','0','bbb@bbbccc',NULL,'$2y$10$on7Tw0PRkm25muzD5g0Hn.CYVZhA33Ttm.qlPo3JUpWrjxz3L9Avi',NULL,'2019-08-23 00:17:04','2019-08-26 18:57:45'),(33,'ccc','ccc','0','ccc@ccc',NULL,'$2y$10$gV1TAAfIh7XKBGVv0G1cF.h9RNtHiCilSM2Fv0LvJSHeIvjnvgKwW',NULL,'2019-08-23 00:17:17','2019-08-26 21:44:46'),(34,'admin','Administrator','99','bryan@tensall.com.tw',NULL,'$2y$10$iReg3ZRCkzZV7tTYz.mb6OeXtTuCA4wNEgEiXbQw9OQsODWwJmRJu',NULL,'2019-08-26 21:40:13','2019-08-26 21:40:13');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

