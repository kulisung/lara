<?php $__env->startSection('title','查詢系統'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <br>
            <h5>查詢結果</h5>
        <p><a href=<?php echo e(route('searchs.index'), false); ?> class="btn btn-success btn-sm">返回</a></p>
        </div>
        <div class="col-12 table-cont" id="table-cont">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>品號</th>
                        <th>品名</th>
                        <th>數量</th>
                        <th>人時</th>
                        <th>機時</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($work->MB007, false); ?></td>
                        <td><?php echo e($work->MB002, false); ?></td>
                        <td><?php echo e($work->QTY, false); ?></td>
                        <td><?php echo e($work->hum_time, false); ?></td>
                        <td><?php echo e($work->mac_time, false); ?></td>
                    </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/searchs/ShowWorkingTime.blade.php ENDPATH**/ ?>