<nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #363636;">
    <a class="navbar-brand mb-0 h1" href=<?php echo e(route('index'), false); ?>>Dashboard</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                  <a class="nav-link font-weight-bold" href=<?php echo e(route('index'), false); ?>>Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link font-weight-bold" href=<?php echo e(route('posts.index'), false); ?>>簡易公告系統</a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link font-weight-bold dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">資料查詢</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <a class="dropdown-item font-weight-bold" id='search1' href=<?php echo e(route('searchs.search1'), false); ?>>進貨資訊查詢</a>
                        <a class="dropdown-item font-weight-bold" id='search2' href=<?php echo e(route('searchs.search2'), false); ?>>展場庫存查詢</a>
                        <a class="dropdown-item font-weight-bold" id='search3' href=<?php echo e(route('searchs.search3'), false); ?>>對帳單查詢</a>
                        <a class="dropdown-item font-weight-bold" id='search4' href=<?php echo e(route('searchs.search4'), false); ?>>結帳前&後檢查</a>
                        <a class="dropdown-item font-weight-bold" href=<?php echo e(route('searchs.index'), false); ?>>資料查詢_All</a>
                    </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('AllUserExport'), false); ?>>資料匯入</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('auth.dbresult'), false); ?>>DB連線檢查</a>                    
                </li>
                <?php endif; ?>
                <li class="nav-item">
                  <a class="nav-link font-weight-bold" href="#">Other</a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('login'), false); ?>>Login</a>
                </li>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" ><?php echo e(auth()->user()->name, false); ?> 你好!</a>
                </li
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="<?php echo e(route('logout'), false); ?>" onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();"> Logout
                    </a>
                </li>
                    <form id="logout-form" action="<?php echo e(route('logout'), false); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                    </form>
                <?php if(auth()->user()->user_level==99): ?>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href=<?php echo e(route('UsersProfile.UsersIndex'), false); ?>>使用者列表</a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
</nav><?php /**PATH C:\Web\lara\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>