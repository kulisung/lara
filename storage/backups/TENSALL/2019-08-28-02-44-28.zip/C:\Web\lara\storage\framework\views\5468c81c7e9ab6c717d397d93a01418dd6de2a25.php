<?php $__env->startSection('title','資料查詢系統'); ?>
<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="container" style="background-color:#DEFFFF;">
    <div class="row">
        <div class="col-12">
            <h5>#結帳前檢查(測試)</h5>
            <form method="post" action=<?php echo e(route('searchs.SA_Begin_Check'), false); ?>>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                    <label>起始年月(輸入格式為ex:201908)</label>
                    <input type="text" name="fin_date1"><br>
                    <label>結束日期(輸入格式為ex:201908)</label>
                    <input type="text" name="fin_date2">                    
                    <button type="submit" class="btn btn-primary btn-sm">查詢</button>
                    <button type="submit" class="btn btn-secondary btn-sm" formaction=<?php echo e(route('searchs.SA_Begin_Check'), false); ?> onclick="return confirm('確認是否匯出Excel?');">匯出Excel</button>
            </div>        
            </form>
            <h5>#結帳後檢查(測試)</h5>
            <form method="post" action=<?php echo e(route('searchs.SA_Begin_Check'), false); ?>>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                    <label>起始年月(輸入格式為ex:201908)</label>
                    <input type="text" name="fin_date1"><br>
                    <label>結束日期(輸入格式為ex:201908)</label>
                    <input type="text" name="fin_date2">                    
                    <button type="submit" class="btn btn-primary btn-sm">查詢</button>
                    <button type="submit" class="btn btn-secondary btn-sm" formaction=<?php echo e(route('searchs.SA_Begin_Check'), false); ?> onclick="return confirm('確認是否匯出Excel?');">匯出Excel</button>
            </div>        
            </form>
        </div>
    </div>
</div> 
<?php endif; ?> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Web\lara\resources\views/searchs/search4.blade.php ENDPATH**/ ?>